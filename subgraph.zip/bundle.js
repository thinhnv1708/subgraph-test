'use strict';

var utils = require('@mysten/sui/utils');
var library = require('@prisma/client/runtime/library');

class Chart {
    constructor(identify, store) {
        this.identify = identify;
        this.store = store;
        this.entity = 'chart'; //from prisma
    }
    getId() {
        const { interval, time, pair } = this.identify;
        return `${interval}_${time}_${pair}`;
    }
    initData() {
        const { interval, time, pair } = this.identify;
        return {
            id: this.getId(),
            time,
            close: new library.Decimal(0),
            high: new library.Decimal(0),
            interval,
            low: new library.Decimal(0),
            pair,
        };
    }
    async loadData() {
        if (this.data) {
            return this.data;
        }
        let data = await this.store.loadData(this.entity, this.getId());
        if (!data) {
            data = this.initData();
        }
        this.data = data;
        return this.data;
    }
    save() {
        this.store.save(this.entity, this.data);
    }
    get id() {
        return this.data.id;
    }
    get interval() {
        return this.data.interval;
    }
    get time() {
        return this.data.time;
    }
    get pair() {
        return this.data.pair;
    }
    get close() {
        return this.data.close;
    }
    set close(value) {
        this.data.close = value;
    }
    get high() {
        return this.data.high;
    }
    set high(value) {
        this.data.high = value;
    }
    get low() {
        return this.data.low;
    }
    set low(value) {
        this.data.low = value;
    }
}

class EventProcessor {
    constructor(store, tokenManager) {
        this.store = store;
        this.tokenManager = tokenManager;
    }
}

const REGEX_MOVE_OBJECT_ID = /0x[0-9a-fA-F]{1,64}/g;
const OBJECT_ID_LENGTH = 64;
class Swapped extends EventProcessor {
    constructor(store, tokenManager) {
        super(store, tokenManager);
        this.store = store;
        this.tokenManager = tokenManager;
    }
    async processEvent(event) {
        const periods = Object.values(periodsMap);
        for (const period of periods) {
            const coinTypeX = utils.normalizeStructTag(event.parsedJson.coin_x);
            const coinTypeY = utils.normalizeStructTag(event.parsedJson.coin_y);
            const interval = period.label;
            const time = this.calculateElapsedSinceUnixEpoch(event.timestamp, period.periods);
            const lptype = this.getLPCoinType(event.packageId, coinTypeX, coinTypeY);
            const chart = new Chart({ interval, time: BigInt(time), pair: lptype }, this.store);
            await chart.loadData();
            const amountXAdjusted = new library.Decimal(event.parsedJson.amount_x_in).minus(new library.Decimal(event.parsedJson.amount_x_out));
            const amountYAdjusted = new library.Decimal(event.parsedJson.amount_y_in).minus(new library.Decimal(event.parsedJson.amount_y_out));
            const [coinX, coinY] = await Promise.all([
                this.tokenManager.getToken(coinTypeX),
                this.tokenManager.getToken(coinTypeY),
            ]);
            let price = amountYAdjusted.div(amountXAdjusted).abs();
            price = price.mul(10 ** coinX.decimals).div(10 ** coinY.decimals);
            chart.close = price;
            chart.high = price.gt(chart.high) ? price : chart.high;
            if (chart.low.eq(0)) {
                chart.low = price;
            }
            else {
                chart.low = price.lt(chart.low) ? price : chart.low;
            }
            chart.save();
        }
    }
    getLPCoinType(packageId, coinX = '', coinY = '') {
        const originalCoinX = coinX.replace(REGEX_MOVE_OBJECT_ID, (match) => {
            return `0x${match.slice(2).padStart(OBJECT_ID_LENGTH, '0')}`;
        });
        const originalCoinY = coinY.replace(REGEX_MOVE_OBJECT_ID, (match) => {
            return `0x${match.slice(2).padStart(OBJECT_ID_LENGTH, '0')}`;
        });
        if (originalCoinX < originalCoinY) {
            return `${packageId}::pair::LP<${coinX}, ${coinY}>`;
        }
        else {
            return `${packageId}::pair::LP<${coinY}, ${coinX}>`;
        }
    }
    calculateElapsedSinceUnixEpoch(timestamp, periods) {
        return Math.floor(timestamp / (1000 * periods));
    }
}
const periodsMap = {
    15: {
        label: '15s',
        periods: 15,
    },
    30: {
        label: '30s',
        periods: 30,
    },
    60: {
        label: '1m',
        periods: 60,
    },
    300: {
        label: '5m',
        periods: 300,
    },
    3600: {
        label: '1h',
        periods: 3600,
    },
    7200: {
        label: '2h',
        periods: 7200,
    },
    14400: {
        label: '4h',
        periods: 14400,
    },
    86400: {
        label: '1d',
        periods: 86400,
    },
    604800: {
        label: '7d',
        periods: 604800,
    },
    2592000: {
        label: '30d',
        periods: 2592000,
    },
};

module.exports = Swapped;
